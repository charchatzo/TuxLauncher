compiz --use-root-window &
xfce4-panel &
nm-applet &
/home/xaralabos/Desktop/VALA_TEST/main
